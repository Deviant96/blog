(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 8962:
/***/ ((module) => {

// Exports
module.exports = {
	"card": "BlogCard_card__tj_Wo",
	"date": "BlogCard_date__dE9Rt",
	"imgContainer": "BlogCard_imgContainer__RCZyL",
	"author": "BlogCard_author__rK4wK",
	"authorImg": "BlogCard_authorImg__kYudE",
	"avatar": "BlogCard_avatar__uUkZe",
	"grid": "BlogCard_grid__NeMXA"
};


/***/ }),

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__nLjiQ",
	"footer": "Home_footer____T7K",
	"title": "Home_title__T09hD",
	"description": "Home_description__41Owk",
	"code": "Home_code__suPER",
	"grid": "Home_grid__GxQ85",
	"logo": "Home_logo__27_tb"
};


/***/ }),

/***/ 3267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./styles/Home.module.css
var Home_module = __webpack_require__(1288);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(5805);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./styles/BlogCard.module.css
var BlogCard_module = __webpack_require__(8962);
var BlogCard_module_default = /*#__PURE__*/__webpack_require__.n(BlogCard_module);
;// CONCATENATED MODULE: ./components/BlogCard.js



function BlogPost({ title , author , coverPhoto , datePublished , slug ,  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "/posts/" + slug,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (BlogCard_module_default()).card,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (BlogCard_module_default()).text,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (BlogCard_module_default()).author,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (BlogCard_module_default()).authorImg,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: author.avatar.url,
                                        className: (BlogCard_module_default()).avatar,
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: author.username
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (BlogCard_module_default()).details,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (BlogCard_module_default()).date,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                    children: datePublished
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (BlogCard_module_default()).imgContainer,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: coverPhoto.url,
                        alt: ""
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./pages/index.js





const graphcms = new external_graphql_request_.GraphQLClient("https://api-ap-southeast-2.graphcms.com/v2/cl3zwq5zt1pfp01xs7tja9q9t/master");
const QUERY = external_graphql_request_.gql`
  {
    posts {
      id
      title
      datePublished
      slug
      content {
        html
      }
      author {
        username
        avatar {
          url 
        }
      }
      coverPhoto {
        url
      }
    }
  }
`;
// This will be run at build time. So it will fetch external data and pre-render the content 
async function getStaticProps() {
    const { posts  } = await graphcms.request(QUERY);
    return {
        props: {
            posts
        }
    };
}
function Home({ posts  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: (Home_module_default()).main,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Home_module_default()).grid,
                    children: posts.map((post)=>/*#__PURE__*/ jsx_runtime_.jsx(BlogPost, {
                            title: post.title,
                            author: post.author,
                            coverPhoto: post.coverPhoto,
                            datePublished: post.datePublished,
                            slug: post.slug
                        }, post.id))
                })
            })
        ]
    });
};


/***/ }),

/***/ 5805:
/***/ ((module) => {

"use strict";
module.exports = require("graphql-request");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664], () => (__webpack_exec__(3267)));
module.exports = __webpack_exports__;

})();