(() => {
var exports = {};
exports.id = 922;
exports.ids = [922];
exports.modules = {

/***/ 6501:
/***/ ((module) => {

// Exports
module.exports = {
	"blog__cover": "Slug_blog__cover__Ui9Cu",
	"blog__container": "Slug_blog__container__hjszh",
	"article": "Slug_article__IzrZh",
	"article__title": "Slug_article__title__6krcg",
	"article__content": "Slug_article__content__Hn_5L",
	"article__published-date": "Slug_article__published-date__yFbyU",
	"article__avatar": "Slug_article__avatar__RGr_M",
	"author": "Slug_author__B6Kwp"
};


/***/ }),

/***/ 1663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ BlogPost),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6501);
/* harmony import */ var _styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_2__);




const graphcms = new graphql_request__WEBPACK_IMPORTED_MODULE_2__.GraphQLClient("https://api-ap-southeast-2.graphcms.com/v2/cl3zwq5zt1pfp01xs7tja9q9t/master");
const QUERY = graphql_request__WEBPACK_IMPORTED_MODULE_2__.gql`
    query Post($slug: String!) {
        post(where: {slug: $slug}) {
            id
            title
            slug
            datePublished
            author {
                id
                username
                avatar {
                    url
                }
            }
            content {
                html
            }
            coverPhoto{
                id
                url
            }
        }
    }
`;
const SLUGSLIST = graphql_request__WEBPACK_IMPORTED_MODULE_2__.gql`
    {
        posts {
            slug
        }
    }
`;
async function getStaticPaths() {
    const { posts  } = await graphcms.request(SLUGSLIST);
    return {
        paths: posts.map((post)=>({
                params: {
                    slug: post.slug
                }
            })),
        fallback: false
    };
}
async function getStaticProps({ params  }) {
    const slug = params.slug;
    const data = await graphcms.request(QUERY, {
        slug
    });
    const post = data.post;
    return {
        props: {
            post
        }
    };
}
function BlogPost({ post  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: post.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: post.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog__cover),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: post.coverPhoto.url,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().blog__container),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().article),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().article__title),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        children: post.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default()["article__published-date"]),
                                        children: post.datePublished
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().article__content),
                                dangerouslySetInnerHTML: {
                                    __html: post.content.html
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().author),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().authtext),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        children: "About Author"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        children: post.author.username
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: post.author.avatar.url,
                                className: (_styles_Slug_module_css__WEBPACK_IMPORTED_MODULE_3___default().article__avatar),
                                alt: ""
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 5805:
/***/ ((module) => {

"use strict";
module.exports = require("graphql-request");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1663));
module.exports = __webpack_exports__;

})();